﻿// Harsh Patel 8913372
// Khush Patel 8958863
// this is for Manage clinical notes.


using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

public class ClinicalNoteManager
{
    private string filePath = "clinical_notes.as3";
    public List<ClinicalNote> Notes { get; set; }

    public ClinicalNoteManager()
    {
        Notes = new List<ClinicalNote>();
        LoadNotesFromFile();
    }

    public void LoadNotesFromFile()
    {
        if (!File.Exists(filePath)) return;

        var lines = File.ReadAllLines(filePath);
        foreach (var line in lines)
        {
            var parts = line.Split('|');
            if (parts.Length < 5)
            {
                Console.WriteLine($"Error loading note: {line}. The line does not contain the expected number of fields.");
                continue;
            }

            try
            {
                var note = new ClinicalNote
                {
                    NoteID = int.Parse(parts[0]),
                    PatientName = parts[1],
                    DOB = DateTime.Parse(parts[2]),
                    NoteContent = parts[3],
                    Problems = parts[4].Split(';').ToList()
                };
                Notes.Add(note);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error parsing note: {line}. Exception: {ex.Message}");
            }
        }
    }

    public void SaveNotesToFile()
    {
        var lines = Notes.Select(n => $"{n.NoteID}|{n.PatientName}|{n.DOB}|{n.NoteContent}|{string.Join(";", n.Problems)}");
        File.WriteAllLines(filePath, lines);
    }

    public void AddNote(ClinicalNote note)
    {
        Notes.Add(note);
        SaveNotesToFile();
    }

    public void UpdateNote(ClinicalNote note)
    {
        var existingNote = Notes.FirstOrDefault(n => n.NoteID == note.NoteID);
        if (existingNote != null)
        {
            existingNote.PatientName = note.PatientName;
            existingNote.DOB = note.DOB;
            existingNote.NoteContent = note.NoteContent;
            existingNote.Problems = note.Problems;
            SaveNotesToFile();
        }
    }

    public void DeleteNote(int noteID)
    {
        var note = Notes.FirstOrDefault(n => n.NoteID == noteID);
        if (note != null)
        {
            Notes.Remove(note);
            SaveNotesToFile();
        }
    }
}
