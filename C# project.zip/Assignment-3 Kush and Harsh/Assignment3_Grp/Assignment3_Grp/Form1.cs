﻿// Harsh Patel 8913372
// Khush Patel 8958863


using System;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Assignment3_Grp
{
    public partial class Form1 : Form
    {
        private ClinicalNoteManager noteManager;
        private bool isEditMode = false;
        private int selectedNoteID = -1;

        public Form1()
        {
            InitializeComponent();
            noteManager = new ClinicalNoteManager();
            LoadNotesToListBox();
            SetAwaitingNoteMode();
        }

        private void LoadNotesToListBox()
        {
            listBoxNotes.Items.Clear();
            foreach (var note in noteManager.Notes)
            {
                listBoxNotes.Items.Add($"{note.PatientName} (Note: {note.NoteID})");
            }
        }

        private void SetAwaitingNoteMode()
        {
            btnUpdateNote.Enabled = false;
            btnDeleteNote.Enabled = false;
            btnAddNote.Enabled = true;
            txtPatientName.Clear();
            dtpDOB.Value = DateTime.Now;
            richTextBoxNoteContent.Clear();
            listBoxProblems.Items.Clear();
            listBoxVitals.Items.Clear();
            txtNoteID.Text = string.Empty;
            isEditMode = false;
            selectedNoteID = -1;
        }

        private void SetEditMode()
        {
            btnUpdateNote.Enabled = true;
            btnDeleteNote.Enabled = true;
            btnAddNote.Enabled = false;
            isEditMode = true;
        }

        private void btnStartNewNote_Click(object sender, EventArgs e)
        {
            SetAwaitingNoteMode();
            txtNoteID.Text = (noteManager.Notes.Any() ? noteManager.Notes.Max(n => n.NoteID) + 1 : 1).ToString();
            btnAddNote.Enabled = true;
        }

        private void btnAddNote_Click(object sender, EventArgs e)
        {
            if (ValidateInputs())
            {
                var note = new ClinicalNote
                {
                    NoteID = int.Parse(txtNoteID.Text),
                    PatientName = txtPatientName.Text,
                    DOB = dtpDOB.Value,
                    NoteContent = richTextBoxNoteContent.Text,
                    Problems = listBoxProblems.Items.Cast<string>().ToList()
                };
                noteManager.AddNote(note);
                LoadNotesToListBox();
                SetAwaitingNoteMode();
            }
        }

        private void btnUpdateNote_Click(object sender, EventArgs e)
        {
            if (ValidateInputs() && selectedNoteID != -1)
            {
                var note = noteManager.Notes.First(n => n.NoteID == selectedNoteID);
                note.PatientName = txtPatientName.Text;
                note.DOB = dtpDOB.Value;
                note.NoteContent = richTextBoxNoteContent.Text;
                note.Problems = listBoxProblems.Items.Cast<string>().ToList();
                noteManager.UpdateNote(note);
                LoadNotesToListBox();
                SetAwaitingNoteMode();
            }
        }

        private void btnDeleteNote_Click(object sender, EventArgs e)
        {
            if (selectedNoteID != -1)
            {
                noteManager.DeleteNote(selectedNoteID);
                LoadNotesToListBox();
                SetAwaitingNoteMode();
            }
        }

        private void listBoxNotes_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxNotes.SelectedIndex != -1)
            {
                var selectedNote = noteManager.Notes[listBoxNotes.SelectedIndex];
                txtNoteID.Text = selectedNote.NoteID.ToString();
                txtPatientName.Text = selectedNote.PatientName;
                dtpDOB.Value = selectedNote.DOB;
                richTextBoxNoteContent.Text = selectedNote.NoteContent;
                listBoxProblems.Items.Clear();
                foreach (var problem in selectedNote.Problems)
                {
                    listBoxProblems.Items.Add(problem);
                }
                selectedNoteID = selectedNote.NoteID;
                ExtractVitals(selectedNote.NoteContent);
                SetEditMode();
            }
        }

        private void btnAddProblem_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtNewProblem.Text))
            {
                listBoxProblems.Items.Add(txtNewProblem.Text);
                txtNewProblem.Clear();
            }
        }

        private void btnRemoveProblem_Click(object sender, EventArgs e)
        {
            if (listBoxProblems.SelectedIndex != -1)
            {
                listBoxProblems.Items.RemoveAt(listBoxProblems.SelectedIndex);
            }
            else
            {
                MessageBox.Show("Please select a problem to remove.");
            }
        }

        private void ExtractVitals(string noteContent)
        {
            listBoxVitals.Items.Clear();
            var bpPattern = @"BP[:\s]*(\d{2,3})\/(\d{2,3})";
            var hrPattern = @"HR[:\s]*(\d{2,3})";

            var bpMatches = Regex.Matches(noteContent, bpPattern);
            foreach (Match match in bpMatches)
            {
                var bp = new BloodPressure
                {
                    Systolic = int.Parse(match.Groups[1].Value),
                    Diastolic = int.Parse(match.Groups[2].Value),
                    Type = "BP",
                    Unit = "mmHg"
                };
                listBoxVitals.Items.Add($"{bp.Type}: {bp.Systolic}/{bp.Diastolic} {bp.Unit} {(bp.IsHigh ? "High" : bp.IsLow ? "Low" : "")}");
            }

            var hrMatches = Regex.Matches(noteContent, hrPattern);
            foreach (Match match in hrMatches)
            {
                var hr = new HeartRate
                {
                    BPM = int.Parse(match.Groups[1].Value),
                    Type = "HR",
                    Unit = "bpm"
                };
                listBoxVitals.Items.Add($"{hr.Type}: {hr.BPM} {hr.Unit} {(hr.IsHigh ? "High" : hr.IsLow ? "Low" : "")}");
            }
        }

        private bool ValidateInputs()
        {
            if (string.IsNullOrWhiteSpace(txtPatientName.Text))
            {
                MessageBox.Show("Patient name is required.");
                return false;
            }
            if (dtpDOB.Value > DateTime.Now)
            {
                MessageBox.Show("DOB cannot be in the future.");
                return false;
            }
            if (string.IsNullOrWhiteSpace(richTextBoxNoteContent.Text))
            {
                MessageBox.Show("Clinical note content is required.");
                return false;
            }
            return true;
        }
    }
}
