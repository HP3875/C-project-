﻿public abstract class Vital
{
    public string Type { get; set; }
    public string Unit { get; set; }
    public abstract bool IsHigh { get; }
    public abstract bool IsLow { get; }
}

public class BloodPressure : Vital
{
    public int Systolic { get; set; }
    public int Diastolic { get; set; }

    public override bool IsHigh => Systolic > 130 || Diastolic > 80;
    public override bool IsLow => Systolic < 90 || Diastolic < 60;
}

public class HeartRate : Vital
{
    public int BPM { get; set; }

    public override bool IsHigh => BPM > 100;
    public override bool IsLow => BPM < 60;
}
