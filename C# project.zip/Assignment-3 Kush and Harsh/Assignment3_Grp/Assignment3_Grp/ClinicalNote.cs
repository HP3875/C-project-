﻿// Harsh Patel 8913372
// Khush Patel 8958863




using System;
using System.Collections.Generic;

public class ClinicalNote
{
    public int NoteID { get; set; }
    public string PatientName { get; set; }
    public DateTime DOB { get; set; }
    public string NoteContent { get; set; }
    public List<string> Problems { get; set; }
}
