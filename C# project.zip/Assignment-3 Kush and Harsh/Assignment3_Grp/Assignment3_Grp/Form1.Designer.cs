﻿using System.Windows.Forms;

namespace Assignment3_Grp
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.ListBox listBoxNotes;
        private System.Windows.Forms.Button btnStartNewNote;
        private System.Windows.Forms.Button btnAddNote;
        private System.Windows.Forms.Button btnUpdateNote;
        private System.Windows.Forms.Button btnDeleteNote;
        private System.Windows.Forms.TextBox txtPatientName;
        private System.Windows.Forms.DateTimePicker dtpDOB;
        private System.Windows.Forms.TextBox txtNewProblem;
        private System.Windows.Forms.Button btnAddProblem;
        private System.Windows.Forms.Button btnRemoveProblem; // Add this line
        private System.Windows.Forms.ListBox listBoxProblems;
        private System.Windows.Forms.RichTextBox richTextBoxNoteContent;
        private System.Windows.Forms.ListBox listBoxVitals;
        private System.Windows.Forms.Label lblNoteID;
        private System.Windows.Forms.Label lblPatientName;
        private System.Windows.Forms.Label lblDOB;
        private System.Windows.Forms.Label lblNewProblem;
        private System.Windows.Forms.Label lblNotes;
        private System.Windows.Forms.Label lblProblems;
        private System.Windows.Forms.Label lblVitals;
        private System.Windows.Forms.TextBox txtNoteID;

        private void InitializeComponent()
        {
            this.listBoxNotes = new System.Windows.Forms.ListBox();
            this.btnStartNewNote = new System.Windows.Forms.Button();
            this.btnAddNote = new System.Windows.Forms.Button();
            this.btnUpdateNote = new System.Windows.Forms.Button();
            this.btnDeleteNote = new System.Windows.Forms.Button();
            this.txtPatientName = new System.Windows.Forms.TextBox();
            this.dtpDOB = new System.Windows.Forms.DateTimePicker();
            this.txtNewProblem = new System.Windows.Forms.TextBox();
            this.btnAddProblem = new System.Windows.Forms.Button();
            this.btnRemoveProblem = new System.Windows.Forms.Button();
            this.listBoxProblems = new System.Windows.Forms.ListBox();
            this.richTextBoxNoteContent = new System.Windows.Forms.RichTextBox();
            this.listBoxVitals = new System.Windows.Forms.ListBox();
            this.lblNoteID = new System.Windows.Forms.Label();
            this.lblPatientName = new System.Windows.Forms.Label();
            this.lblDOB = new System.Windows.Forms.Label();
            this.lblNewProblem = new System.Windows.Forms.Label();
            this.lblNotes = new System.Windows.Forms.Label();
            this.lblProblems = new System.Windows.Forms.Label();
            this.lblVitals = new System.Windows.Forms.Label();
            this.txtNoteID = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // listBoxNotes
            // 
            this.listBoxNotes.FormattingEnabled = true;
            this.listBoxNotes.ItemHeight = 16;
            this.listBoxNotes.Location = new System.Drawing.Point(12, 76);
            this.listBoxNotes.Name = "listBoxNotes";
            this.listBoxNotes.Size = new System.Drawing.Size(221, 356);
            this.listBoxNotes.TabIndex = 0;
            this.listBoxNotes.SelectedIndexChanged += new System.EventHandler(this.listBoxNotes_SelectedIndexChanged);
            // 
            // btnStartNewNote
            // 
            this.btnStartNewNote.Location = new System.Drawing.Point(12, 28);
            this.btnStartNewNote.Name = "btnStartNewNote";
            this.btnStartNewNote.Size = new System.Drawing.Size(221, 31);
            this.btnStartNewNote.TabIndex = 1;
            this.btnStartNewNote.Text = "Start new note";
            this.btnStartNewNote.UseVisualStyleBackColor = true;
            this.btnStartNewNote.Click += new System.EventHandler(this.btnStartNewNote_Click);
            // 
            // btnAddNote
            // 
            this.btnAddNote.Location = new System.Drawing.Point(255, 533);
            this.btnAddNote.Name = "btnAddNote";
            this.btnAddNote.Size = new System.Drawing.Size(100, 23);
            this.btnAddNote.TabIndex = 2;
            this.btnAddNote.Text = "Add note";
            this.btnAddNote.UseVisualStyleBackColor = true;
            this.btnAddNote.Click += new System.EventHandler(this.btnAddNote_Click);
            // 
            // btnUpdateNote
            // 
            this.btnUpdateNote.Location = new System.Drawing.Point(361, 533);
            this.btnUpdateNote.Name = "btnUpdateNote";
            this.btnUpdateNote.Size = new System.Drawing.Size(100, 23);
            this.btnUpdateNote.TabIndex = 3;
            this.btnUpdateNote.Text = "Update note";
            this.btnUpdateNote.UseVisualStyleBackColor = true;
            this.btnUpdateNote.Click += new System.EventHandler(this.btnUpdateNote_Click);
            // 
            // btnDeleteNote
            // 
            this.btnDeleteNote.Location = new System.Drawing.Point(467, 533);
            this.btnDeleteNote.Name = "btnDeleteNote";
            this.btnDeleteNote.Size = new System.Drawing.Size(100, 23);
            this.btnDeleteNote.TabIndex = 4;
            this.btnDeleteNote.Text = "Delete note";
            this.btnDeleteNote.UseVisualStyleBackColor = true;
            this.btnDeleteNote.Click += new System.EventHandler(this.btnDeleteNote_Click);
            // 
            // txtPatientName
            // 
            this.txtPatientName.Location = new System.Drawing.Point(361, 95);
            this.txtPatientName.Name = "txtPatientName";
            this.txtPatientName.Size = new System.Drawing.Size(206, 22);
            this.txtPatientName.TabIndex = 5;
            // 
            // dtpDOB
            // 
            this.dtpDOB.Location = new System.Drawing.Point(361, 189);
            this.dtpDOB.Name = "dtpDOB";
            this.dtpDOB.Size = new System.Drawing.Size(206, 22);
            this.dtpDOB.TabIndex = 6;
            // 
            // txtNewProblem
            // 
            this.txtNewProblem.Location = new System.Drawing.Point(361, 267);
            this.txtNewProblem.Name = "txtNewProblem";
            this.txtNewProblem.Size = new System.Drawing.Size(206, 22);
            this.txtNewProblem.TabIndex = 7;
            // 
            // btnAddProblem
            // 
            this.btnAddProblem.Location = new System.Drawing.Point(597, 263);
            this.btnAddProblem.Name = "btnAddProblem";
            this.btnAddProblem.Size = new System.Drawing.Size(100, 23);
            this.btnAddProblem.TabIndex = 8;
            this.btnAddProblem.Text = "Add";
            this.btnAddProblem.UseVisualStyleBackColor = true;
            this.btnAddProblem.Click += new System.EventHandler(this.btnAddProblem_Click);
            // 
            // btnRemoveProblem
            // 
            this.btnRemoveProblem.Location = new System.Drawing.Point(597, 213);
            this.btnRemoveProblem.Name = "btnRemoveProblem";
            this.btnRemoveProblem.Size = new System.Drawing.Size(100, 23);
            this.btnRemoveProblem.TabIndex = 9;
            this.btnRemoveProblem.Text = "Remove problem";
            this.btnRemoveProblem.UseVisualStyleBackColor = true;
            this.btnRemoveProblem.Click += new System.EventHandler(this.btnRemoveProblem_Click);
            // 
            // listBoxProblems
            // 
            this.listBoxProblems.FormattingEnabled = true;
            this.listBoxProblems.ItemHeight = 16;
            this.listBoxProblems.Location = new System.Drawing.Point(597, 49);
            this.listBoxProblems.Name = "listBoxProblems";
            this.listBoxProblems.Size = new System.Drawing.Size(183, 148);
            this.listBoxProblems.TabIndex = 10;
            // 
            // richTextBoxNoteContent
            // 
            this.richTextBoxNoteContent.Location = new System.Drawing.Point(257, 353);
            this.richTextBoxNoteContent.Name = "richTextBoxNoteContent";
            this.richTextBoxNoteContent.Size = new System.Drawing.Size(712, 170);
            this.richTextBoxNoteContent.TabIndex = 11;
            this.richTextBoxNoteContent.Text = "";
            // 
            // listBoxVitals
            // 
            this.listBoxVitals.FormattingEnabled = true;
            this.listBoxVitals.ItemHeight = 16;
            this.listBoxVitals.Location = new System.Drawing.Point(819, 49);
            this.listBoxVitals.Name = "listBoxVitals";
            this.listBoxVitals.Size = new System.Drawing.Size(150, 148);
            this.listBoxVitals.TabIndex = 12;
            // 
            // lblNoteID
            // 
            this.lblNoteID.AutoSize = true;
            this.lblNoteID.Location = new System.Drawing.Point(257, 43);
            this.lblNoteID.Name = "lblNoteID";
            this.lblNoteID.Size = new System.Drawing.Size(55, 16);
            this.lblNoteID.TabIndex = 13;
            this.lblNoteID.Text = "Note ID:";
            // 
            // lblPatientName
            // 
            this.lblPatientName.AutoSize = true;
            this.lblPatientName.Location = new System.Drawing.Point(255, 98);
            this.lblPatientName.Name = "lblPatientName";
            this.lblPatientName.Size = new System.Drawing.Size(88, 16);
            this.lblPatientName.TabIndex = 14;
            this.lblPatientName.Text = "Patient name:";
            // 
            // lblDOB
            // 
            this.lblDOB.AutoSize = true;
            this.lblDOB.Location = new System.Drawing.Point(255, 192);
            this.lblDOB.Name = "lblDOB";
            this.lblDOB.Size = new System.Drawing.Size(82, 16);
            this.lblDOB.TabIndex = 15;
            this.lblDOB.Text = "Date of Birth:";
            // 
            // lblNewProblem
            // 
            this.lblNewProblem.AutoSize = true;
            this.lblNewProblem.Location = new System.Drawing.Point(255, 270);
            this.lblNewProblem.Name = "lblNewProblem";
            this.lblNewProblem.Size = new System.Drawing.Size(90, 16);
            this.lblNewProblem.TabIndex = 16;
            this.lblNewProblem.Text = "New problem:";
            // 
            // lblNotes
            // 
            this.lblNotes.AutoSize = true;
            this.lblNotes.Location = new System.Drawing.Point(257, 323);
            this.lblNotes.Name = "lblNotes";
            this.lblNotes.Size = new System.Drawing.Size(46, 16);
            this.lblNotes.TabIndex = 17;
            this.lblNotes.Text = "Notes:";
            // 
            // lblProblems
            // 
            this.lblProblems.AutoSize = true;
            this.lblProblems.Location = new System.Drawing.Point(594, 18);
            this.lblProblems.Name = "lblProblems";
            this.lblProblems.Size = new System.Drawing.Size(68, 16);
            this.lblProblems.TabIndex = 18;
            this.lblProblems.Text = "Problems:";
            // 
            // lblVitals
            // 
            this.lblVitals.AutoSize = true;
            this.lblVitals.Location = new System.Drawing.Point(816, 18);
            this.lblVitals.Name = "lblVitals";
            this.lblVitals.Size = new System.Drawing.Size(43, 16);
            this.lblVitals.TabIndex = 19;
            this.lblVitals.Text = "Vitals:";
            // 
            // txtNoteID
            // 
            this.txtNoteID.Location = new System.Drawing.Point(361, 37);
            this.txtNoteID.Name = "txtNoteID";
            this.txtNoteID.ReadOnly = true;
            this.txtNoteID.Size = new System.Drawing.Size(41, 22);
            this.txtNoteID.TabIndex = 20;
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(995, 623);
            this.Controls.Add(this.txtNoteID);
            this.Controls.Add(this.lblVitals);
            this.Controls.Add(this.lblProblems);
            this.Controls.Add(this.lblNotes);
            this.Controls.Add(this.lblNewProblem);
            this.Controls.Add(this.lblDOB);
            this.Controls.Add(this.lblPatientName);
            this.Controls.Add(this.lblNoteID);
            this.Controls.Add(this.listBoxVitals);
            this.Controls.Add(this.richTextBoxNoteContent);
            this.Controls.Add(this.listBoxProblems);
            this.Controls.Add(this.btnRemoveProblem);
            this.Controls.Add(this.btnAddProblem);
            this.Controls.Add(this.txtNewProblem);
            this.Controls.Add(this.dtpDOB);
            this.Controls.Add(this.txtPatientName);
            this.Controls.Add(this.btnDeleteNote);
            this.Controls.Add(this.btnUpdateNote);
            this.Controls.Add(this.btnAddNote);
            this.Controls.Add(this.btnStartNewNote);
            this.Controls.Add(this.listBoxNotes);
            this.Name = "Form1";
            this.Text = "Encounter Notes";
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}
